<?php
/**
 * @file		defaultSection.php 	Define the default section for the 'warnings' module
 *~TERABYTE_DOC_READY~
 * $Copyright: (c) 2001 - 2011 Invision Power Services, Inc.$
 * $License: http://www.invisionpower.com/company/standards.php#license$
 * $Author: ips_terabyte $
 * @since		07th May 2012
 * $LastChangedDate: 2012-05-07 11:22:43 -0400 (Mon, 07 May 2012) $
 * @version		v3.4.6
 * $Revision: 10695 $
 */

$DEFAULT_SECTION = 'reasons';
